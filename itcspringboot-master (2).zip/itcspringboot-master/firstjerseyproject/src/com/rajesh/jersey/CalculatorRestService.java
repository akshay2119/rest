package com.rajesh.jersey;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.entity.Employee;

@Path("/Calculator")
public class CalculatorRestService {
	@PUT
	@Path("/add")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public String addition(@FormParam("nm") String name,@FormParam("ps") String pass,@FormParam("em") String email,@FormParam("ad") String address){
		
		String result="<result>Registration Fail</result>";
		if(name.equals("rkcp") && pass.equals("informatiom")){
			result="<result>Registration Success</result>";
		}
		
		
		return result;
	}
	@GET
	@Path("/allRecord")
	@Produces(MediaType.APPLICATION_XML)
	public List<Employee> getAllRecord(){
		Employee ee=new Employee();
		ee.setName("rajesh");
		ee.setAddress("bangalore");
		ee.setEmail("abc@yahoo.com");
		ee.setPassword("abc");
		Employee ee1=new Employee();
		ee1.setName("rajesh1");
		ee1.setAddress("bangalore1");
		ee1.setEmail("abc1@yahoo.com");
		ee1.setPassword("abc1");
		Employee ee2=new Employee();
		ee2.setName("rajesh2");
		ee2.setAddress("bangalore2");
		ee2.setEmail("abc2@yahoo.com");
		ee2.setPassword("abc2");
		List<Employee> ll=new ArrayList<Employee>();
		ll.add(ee);
		ll.add(ee1);
		ll.add(ee2);
		return ll;
	}
	
	
	   @GET
	   @Path("/allRecord/{empid}")
	   @Produces(MediaType.APPLICATION_XML)
	   public Employee getUser(@PathParam("empid") int userid){
		   Employee ee2=new Employee();
			ee2.setName("rajesh2");
			ee2.setAddress("bangalore2");
			ee2.setEmail("abc2@yahoo.com");
			ee2.setPassword("abc2");
	      return ee2;
	   }
	
	
	   @POST
	   @Path("/editEmployee")
	   @Produces(MediaType.APPLICATION_XML)
	   @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	   public String editProfile(@FormParam("nm") String name,@FormParam("ps") String pass,@FormParam("em") String email,@FormParam("ad") String address){
			
			String result="<result>update Fail</result>";
			if(name.equals("rkcp") && pass.equals("informatiom")){
				result="<result>update Success</result>";
			}
			
			
			return result;
		}
	   @DELETE
	   @Path("/allRecord/{empid}/{empname}/{empage}")
	   @Produces(MediaType.APPLICATION_XML)
	   public String deleteUser(@PathParam("empid") int empid,@PathParam("empid") int empid3,@PathParam("empid") int empid1){
		  
	      return "record deleted";
	   }
	
	
	
	
	   
}








