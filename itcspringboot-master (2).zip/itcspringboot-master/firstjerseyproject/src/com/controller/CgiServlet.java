package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.client.ClientConfig;

import com.entity.Employee;


public class CgiServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//ServletConfig sf=getServletConfig();
		ServletContext sf=getServletContext();
		String ss=sf.getInitParameter("abc").toString();
		System.out.println(ss);
		
		String name=request.getParameter("name");
		String password=request.getParameter("pass");
		String email=request.getParameter("email");
		String address=request.getParameter("address");
		Form f=new Form();
		f.param("nm", name);
		f.param("ps", password);
		f.param("em", email);
		f.param("ad", address);
		//ClientConfig cf=new ClientConfig();
		Client cc=ClientBuilder.newClient();
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html><body>");
		String result=cc
        .target("http://localhost:10000/firstjerseyproject/rest/Calculator/add")
        .request(MediaType.APPLICATION_XML)
        .put(Entity.entity(f,
           MediaType.APPLICATION_FORM_URLENCODED_TYPE),
           String.class);
		
		out.println(result);
		     /* GenericType<ArrayList<Employee>> list = new GenericType<ArrayList<Employee>>() {};
		   //   List<Employee> list=new ArrayList<Employee>();
		      List<Employee> users = 
		    		  cc.target("http://localhost:10000/firstjerseyproject/rest/Calculator/allRecord")
		    		  .request(MediaType.APPLICATION_XML)
		    		  .get(list);
		     
		      for(Employee u:users){
		    	 out.println(u.getName()+" "+u.getAddress()+" "+u.getEmail()+"  "+u.getPassword());
		      }
		      if(users.isEmpty()){
		        out.println("fail to retrive record or might be no record");
		      }*/
		  
		//view particular record
		/*Employee u = cc
		    	         .target("http://localhost:10000/firstjerseyproject/rest/Calculator/allRecord")
		    	         .path("/{empid}")
		    	         .resolveTemplate("empid", 1)
		    	         .request(MediaType.APPLICATION_XML)
		    	         .get(Employee.class);
		out.println(u.getName()+" "+u.getAddress()+" "+u.getEmail()+"  "+u.getPassword());*/
		  
		
		//updation
		      
		/*Form f=new Form();
		f.param("nm", name);
		f.param("ps", password);
		f.param("em", email);
		f.param("ad", address);

	      String ru = cc
	         .target("http://localhost:10000/firstjerseyproject/rest/Calculator/editEmployee")
	         .request(MediaType.APPLICATION_XML)
	         .post(Entity.entity(f,
	            MediaType.APPLICATION_FORM_URLENCODED_TYPE),
	            String.class);
	     out.println(ru);*/
	     

	  //deletion    
	      
	     /* String rr = cc
	    	         .target("http://localhost:10000/firstjerseyproject/rest/Calculator/allRecord?empid=")
	    	         .path("/{empid}")
	    	         .resolveTemplate("empid", 11)
	    	          .path("/{empid}")
	    	         .resolveTemplate("empid", 11)
	    	          .path("/{empid}")
	    	         .resolveTemplate("empid", 11)
	    	         .request(MediaType.APPLICATION_XML)
	    	         .delete(String.class);

	    	     
	    	    	  out.println(rr);*/
	    	     
		      
		      
		      
		  /* private void testGetUser(){
		      User sampleUser = new User();
		      sampleUser.setId(1);

		      User user = client
		         .target(REST_SERVICE_URL)
		         .path("/{userid}")
		         .resolveTemplate("userid", 1)
		         .request(MediaType.APPLICATION_XML)
		         .get(User.class);
		      String result = FAIL;
		      if(sampleUser != null && sampleUser.getId() == user.getId()){
		    	  System.out.println(user.getName());
		         result = PASS;
		      }
		      System.out.println("Test case name: testGetUser, Result: " + result );
		   }
		*/
		
		
		out.println("</body></html>");
	}

}















