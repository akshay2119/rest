import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.XMLType;
import javax.xml.rpc.ParameterMode;
public class Calcclient{
   public static void main(String [] args) throws Exception {
      String endpoint = "http://localhost:10000/firstsoapservice/Calculator.jws";
      String method = args[0];
       Integer i1 = new Integer(args[1]);
       Integer i2 = new Integer(args[2]);
       //step 1
       Service  service = new Service();
       //step 2
       Call     call    = (Call) service.createCall();
       call.setTargetEndpointAddress( new java.net.URL(endpoint) );
       call.setOperationName( method );
       call.addParameter( "op1", XMLType.XSD_INT, ParameterMode.IN );
       call.addParameter( "op2", XMLType.XSD_INT, ParameterMode.IN );
       call.setReturnType( XMLType.XSD_INT );
      //   call.setProperty(Call.USERNAME_PROPERTY, "mahesh");
     //   call.setProperty(Call.PASSWORD_PROPERTY, "saha");
       
       // step 3
       Integer ret = (Integer) call.invoke( new Object [] { i1, i2 });
        System.out.println("Got result : " + ret);
   }
}







































