package com.spbootmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	@RequestMapping("/register.htm")
	public ModelAndView registerUser(@RequestParam("name") String name,@RequestParam("pass") String password){
		ModelAndView mv=new ModelAndView();
		String message="registration fail";
		if(name.equals("rkcp")&& password.equals("information")){
			message="registration success";
			
		}
		
		mv.addObject("result",message);
		mv.setViewName("register");
		
		return mv;
	}
	
	@RequestMapping("/login.htm")
	public String loginUser(){
		ModelAndView mv=new ModelAndView();
		
	
		return "welcome";
	}
	
	@RequestMapping("home")
	public String deleteUser(){
		
		return "register";
	}
	
}








