package com.spbootmvc;

import static java.lang.System.exit;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;


@SpringBootApplication
public class SpbootApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		
		SpringApplication.run(SpbootApplication.class, args);
	}
	
	/*@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(SpbootApplication.class);
	}

	public static void main(String[] args) throws Exception {
		SpringApplication.run(SpbootApplication.class, args);
	}*/
	
}
