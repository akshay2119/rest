

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

public class WiproServlet extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ClientConfig config = new ClientConfig();
	    Client client = ClientBuilder.newClient(config);
	    WebTarget target = client.target(getBaseURI());
	    
	    response.setContentType("text/html");
	    PrintWriter out=response.getWriter();
	    
	    out.println("<html><body>");
	    out.println("calling restful with servlet");
	    
	   // System.out.println(target.path("rest").path("calc").request().accept(MediaType.TEXT_PLAIN).get(String.class));
	  //  System.out.println(target.path("rest").path("calc").request().accept(MediaType.TEXT_XML).get(String.class));
	    out.println(target.path("rest").path("abc").path("calc")
	    	.request().accept(MediaType.TEXT_HTML).get(String.class));
	    out.println("</body></html>");
	  }
	  private static URI getBaseURI() { 
	    return UriBuilder.fromUri("http://localhost:10000/restfuljersey").build();
	  }

}














