package com.rajesh.jersey;

import java.io.File;

import javax.annotation.security.DenyAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

@Path("/sgservice3")
public class TextFileDownload {

	private static final String FILE_PATH = "c:\\account_rkcp.log";
	//@RolesAllowed("sg")
	
	@GET
	@Path("/file")
	@Produces("text/plain")
	@DenyAll
	public Response getFile() {

		File file = new File(FILE_PATH);

		ResponseBuilder response = Response.ok((Object) file);
		response.header("Content-Disposition",
				"attachment; filename=\"file_from_server.log\"");
		return response.build();

	}

}