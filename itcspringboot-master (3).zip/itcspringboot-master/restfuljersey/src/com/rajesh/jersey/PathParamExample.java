package com.rajesh.jersey;


import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

@Path("/sgservice")
public class PathParamExample {
	@GET
	@Path("{uid}")
	public Response getUserById(@PathParam("uid") String id) {
		return Response.status(200).entity("welcome : " + id)
				.build();
	}

	@GET
	@Path("{year}/{month}/{day}")
	public Response getUserHistory(@PathParam("year") int year,
			@PathParam("month") int month, @PathParam("day") int day) {
		String date = year + "/" + month + "/" + day;
		return Response.status(200)
				.entity("you entered : " + date)
				.build();

	}
	
}