package com.rajesh.jersey;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

@Path("/sgservice1")
public class PathURIMatchingExample {

	@GET
	public Response getUser() {

		return Response.status(200).entity("getUser is called").build();

	}

	@GET
	@Path("/vip")
	public Response getUserVIP() {

		return Response.status(200).entity("simple").build();

	}

	@GET
	@Path("{name}")
	public Response getUserByName(@PathParam("name") String name) {

		return Response.status(200)
				.entity("getUserByName is called, name : " + name).build();

	}

	@GET
	@Path("{id : \\d+}")
	public Response getUserById(@PathParam("id") String id) {
		return Response.status(200).entity("integer id called, id : " + id)
				.build();
	}
	@GET
	@Path("/username/{username : [a-zA-Z_0-9][a-zA-Z_0-9]}")
	public Response getUserByUserName(@PathParam("username") String username) {
		return Response.status(200)
				.entity("regular expression called, username : " + username)
				.build();
	}
	@GET
	@Path("/books/{isbn : \\d+}")
	public Response getUserBookByISBN(@PathParam("isbn") String isbn) {
		return Response.status(200)
				.entity("integer id called : " + isbn).build();
	}

}