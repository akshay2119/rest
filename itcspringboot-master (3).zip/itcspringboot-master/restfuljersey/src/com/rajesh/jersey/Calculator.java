package com.rajesh.jersey;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/abc")
public class Calculator {
  @GET
  @Path("/calc")
  @Produces(MediaType.TEXT_HTML)
  public Response add(){
	  return Response.status(200).entity("<html><body> addition is <br>"
	  		+ " "+(3+5)+" </body></html>").build();
	  
  }
  

} 









