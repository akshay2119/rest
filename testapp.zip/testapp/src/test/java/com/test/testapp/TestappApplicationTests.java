package com.test.testapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestappApplicationTests {

	@Test
	void contextLoads() {
	}

}
